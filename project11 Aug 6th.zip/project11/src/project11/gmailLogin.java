package project11;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class gmailLogin {

	public static void main(String[] args) {
	
		WebDriver driver =new FirefoxDriver();
		driver.get("https://www.google.com/");
		driver.findElement(By.linkText("Gmail")).click();
		driver.findElement(By.linkText("SIGN IN")).click();
		

		driver.findElement(By.id("identifierId")).sendKeys("vimelsh073");
		driver.findElement(By.id("identifierNext")).click();
		
		
		
		
		
		

	}

}
