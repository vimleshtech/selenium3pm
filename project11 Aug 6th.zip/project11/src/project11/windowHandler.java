package project11;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class windowHandler {

	public static void main(String[] args) {

		//here driver is object ot FirefoxDriver()		
		WebDriver driver =new FirefoxDriver();
		driver.get("https://www.naukri.com/");
		
		Set<String> wins= 	driver.getWindowHandles();
	
		System.out.println(wins.size());
		for(String win: wins)
		{
			driver.switchTo().window(win);
			String t;
			t =driver.getTitle();
			System.out.println(t);
			
			if(t.contains("Jobs"))
			{
				driver.findElement(By.id("login_Layer")).click();
				try
				{
				driver.findElement(By.id("eLoginNew")).sendKeys("vimlesh073@gmail.com");
				}
				catch (Exception e) {
					// TODO: handle exception
					driver.findElement(By.id("eLogin")).sendKeys("vimlesh073@gmail.com");
				}
				
			}
		}
		

	}

}
