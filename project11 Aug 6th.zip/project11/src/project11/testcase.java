package project11;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class testcase {

	public static void main(String[] a)
	{
		
		//here driver is object ot FirefoxDriver()		
		WebDriver driver =new FirefoxDriver();
		driver.get("https://www.yahoo.com/");
		

		String ps = driver.getPageSource(); //get html source code
		System.out.println(ps);
		
		String url = driver.getCurrentUrl();//get current url 
		System.out.println("current page is :"+url);
		
		String title = driver.getTitle();//get title of web page
		System.out.println(title);
		

		//get count of urls/hyperlink
		List<WebElement> els	 = driver.findElements(By.tagName("a"));
		
		for(WebElement el  : els)
		{
			System.out.println(el.getText());
		}
	
		System.out.println("a tag counts : "+els.size());
		
		
	}
	
}
