package project11;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;

public class alertHandler {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		WebDriver driver =new FirefoxDriver();
		driver.get("https://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_alert");
		
		//capture screen
		File src =	((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileHandler.copy(src, new File("C:\\Users\\Tech Vision\\Desktop\\myproject\\out.png"));
		
		driver.switchTo().frame("iframeResult");
		WebElement el =	driver.findElement(By.tagName("button"));
		el.click();
		
		driver.switchTo().alert();
		String ss = driver.switchTo().alert().getText();
		driver.switchTo().alert().dismiss();
		System.out.println(ss);
		//or
		//driver.switchTo().alert().accept();
		
		//class can be multiple times		
		//driver.findElement(By.className("gsfi"));
		//driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div[4]/div/div[4]/div[1]/div[2]/div/ul/li[7]/span[1]/a/img")).click();
		
		//driver.findElement(By.xpath("//*[@id=\"lst-ib\"]")
		//driver.findElement(By.cssSelector(""))
		
	
		
	}

}
